###############################
Program compilation and execution from command line
From src/ directory containing myPackage/ subdirectory
###############################
#Compilation
javac myPackage/Main.java
#Execution
java myPackage/Main
