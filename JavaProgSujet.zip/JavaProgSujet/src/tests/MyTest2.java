package tests;

import static org.junit.Assert.*;

import org.junit.Test;

//The Test annotation indicates that the public void method to which it is attached can be run as a test case.
public class MyTest2 {

	@Test  
	public void test2_1() 
	{
		fail("Test2_1 Not yet implemented");
	}

	@Test
	public void test2_2() 
	{
		fail("Test2_2 Not yet implemented");
	}

}
