package tests;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
	MyTest1.class,
	MyTest2.class
})

public class MyTestSuite1 {  
	}

